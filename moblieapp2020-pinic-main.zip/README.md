# moblieapp2020-pinic
KNU Moblie App Programming 2020 Team Project / 나들이가GO(Go on a Picnic)
